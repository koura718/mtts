---
title: "お問合せ"
date: 2022-03-28T12:15:51+09:00
draft: false
categories: ["", ""]
description: ""
image: ""
tags: ["", ""]
author: "水城卓球スクール"
sitemap:
    changefreq: weekly
    priority: 0.8
---

## お問合せ

<a href="tel:00012345678">000-1234-5678</a>

<a href="sms:09012345678">SMSで送信する</a>
