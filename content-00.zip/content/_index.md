---
title: "水城卓球スクール"
date: 2022-03-28T12:18:41+09:00
draft: false
categories: ["", ""]
description: ""
image: ""
tags: ["", ""]
author: "水城卓球スクール"
sitemap:
    changefreq: weekly
    priority: 0.8
---

## 水城卓球スクールとは

  令和4年5月に太宰府にオープンした卓球場です！
  卓球を始めてみたい、強くなりたい、運動不足の解消、脳の活性化を図りたい、友達を増やしたい等など！
  それぞれの目的にあった指導を心掛けています。
  まだ卓球をされたことがない方（未経験者）も大歓迎です！
  卓球を始めるなら是非水城卓球スクールへどうぞ！
  お待ちしております！

## コーチ紹介

  - 卓球を始めるなら是非水城卓球スクールへどうぞ！
  - お待ちしております！

<div class="card mb-3">
    <div class="row g-3">
      <div class="col-4">
        <img class="rounded" src="/images/blog/101.jpg" alt="">
      </div>
      <div class="col-8">
        <h6><a href="post-single-2.html" class="btn-link stretched-link text-reset fw-bold">The pros and cons of business agency</a></h6>
        <div class="small mt-1">May 17, 2022</div>
      </div>
    </div>
</div>
