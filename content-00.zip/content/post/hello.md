---
title: "はじめまして！"
date: 2022-04-10T16:18:18+09:00
draft: true
categories: ["卓球ニュース", "イベント"]
description: ""
image: ""
tags: ["ニュース", "new", "試合", "卓球の技", "オープニング"]
author: "水城卓球スクール"
---

### 水城卓球スクール オープン
